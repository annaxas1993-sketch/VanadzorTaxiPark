import { createHmac, timingSafeEqual, randomBytes } from 'node:crypto';

const headers = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
};
const json = (statusCode, body, extra = {}) => ({ statusCode, headers: { ...headers, ...extra }, body: JSON.stringify(body) });
const env = (key) => (process.env[key] || '').trim();
const requiredEnv = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_ANON_KEY', 'DISPATCHER_PASSWORD', 'SESSION_SECRET'];
const configMissing = () => requiredEnv.filter((key) => !env(key));
const cookieName = 'vantaxi_session';
const cookieOptions = 'Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800';

function sign(value) {
  return createHmac('sha256', env('SESSION_SECRET')).update(value).digest('base64url');
}
function makeSession(role, id = 'dispatcher') {
  const payload = Buffer.from(JSON.stringify({ role, id, exp: Date.now() + 8 * 60 * 60 * 1000, nonce: randomBytes(8).toString('hex') })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function getSession(event) {
  const rawCookie = event.headers?.cookie || event.headers?.Cookie || '';
  const match = rawCookie.split(';').map((x) => x.trim()).find((x) => x.startsWith(`${cookieName}=`));
  if (!match) return null;
  let token;
  try { token = decodeURIComponent(match.slice(cookieName.length + 1)); } catch { return null; }
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return null;
  const expected = Buffer.from(sign(payload));
  const received = Buffer.from(signature);
  if (expected.length !== received.length || !timingSafeEqual(expected, received)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!data.exp || data.exp < Date.now()) return null;
    return data;
  } catch { return null; }
}
function parseBody(event) {
  try { return JSON.parse(event.body || '{}'); } catch { return null; }
}
function cleanText(value, max) {
  return typeof value === 'string' ? value.trim().replace(/[\u0000-\u001F\u007F]/g, '').slice(0, max) : '';
}
function validPhone(value) { return /^[+\d][\d ()-]{5,28}$/.test(value); }
async function db(path, options = {}) {
  const base = env('SUPABASE_URL').replace(/\/$/, '');
  const response = await fetch(`${base}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: env('SUPABASE_SERVICE_ROLE_KEY'),
      authorization: `Bearer ${env('SUPABASE_SERVICE_ROLE_KEY')}`,
      'content-type': 'application/json',
      ...(options.headers || {}),
    },
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const err = new Error(`Database request failed (${response.status})`);
    err.status = response.status;
    throw err;
  }
  return data;
}
function requireDispatcher(event) {
  const session = getSession(event);
  return session?.role === 'dispatcher' || session?.role === 'admin' ? session : null;
}
function requireDriver(event) {
  const session = getSession(event);
  return session?.role === 'driver' ? session : null;
}
function requireConfigured() {
  return configMissing().length === 0;
}

// Drivers may only move an assigned ride forward through the normal workflow.
// Dispatchers retain an override for corrections and cancellations.
const driverTransitions = {
  assigned: ['accepted', 'cancelled'],
  accepted: ['approaching', 'cancelled'],
  approaching: ['with_passenger', 'cancelled'],
  with_passenger: ['completed', 'cancelled'],
};

export async function handler(event) {
  const method = event.httpMethod || 'GET';
  const action = event.queryStringParameters?.action || '';
  if (method === 'OPTIONS') return { statusCode: 204, headers: { ...headers, 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'content-type' }, body: '' };
  if (!['GET', 'POST'].includes(method)) return json(405, { error: 'Method not allowed' }, { allow: 'GET, POST, OPTIONS' });
  if (!requireConfigured()) return json(503, { error: 'Server is not configured', missing: configMissing() });

  try {
    if (action === 'health' && method === 'GET') return json(200, { ok: true, service: 'VanTaxi API' });

    if (action === 'public-order' && method === 'POST') {
      const body = parseBody(event);
      if (!body) return json(400, { error: 'Invalid JSON' });
      // Honeypot field: bots that fill it are silently rejected.
      if (cleanText(body.website, 200)) return json(200, { ok: true, message: 'Order received' });
      const customer_name = cleanText(body.customer_name, 80);
      const customer_phone = cleanText(body.customer_phone, 30);
      const pickup_address = cleanText(body.pickup_address, 250);
      const destination_address = cleanText(body.destination_address, 250);
      const customer_note = cleanText(body.customer_note, 500);
      if (!customer_name || !validPhone(customer_phone) || !pickup_address || !destination_address) {
        return json(400, { error: 'Name, valid phone, pickup and destination are required' });
      }
      const rows = await db('rides?select=id,status,created_at', {
        method: 'POST',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify({ customer_name, customer_phone, pickup_address, destination_address, customer_note: customer_note || null, status: 'new' }),
      });
      return json(201, { ok: true, order: rows?.[0] || null, message: 'Պատվերն ընդունվեց' });
    }

    if (action === 'dispatcher-login' && method === 'POST') {
      const body = parseBody(event);
      const password = typeof body?.password === 'string' ? body.password : '';
      const expected = Buffer.from(env('DISPATCHER_PASSWORD'));
      const actual = Buffer.from(password);
      if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return json(401, { error: 'Սխալ գաղտնաբառ' });
      const token = makeSession('dispatcher');
      return json(200, { ok: true, role: 'dispatcher' }, { 'set-cookie': `${cookieName}=${encodeURIComponent(token)}; ${cookieOptions}` });
    }

    if (action === 'driver-login' && method === 'POST') {
      const body = parseBody(event);
      const email = cleanText(body?.email, 254).toLowerCase();
      const password = typeof body?.password === 'string' ? body.password : '';
      if (!email || !password || password.length > 256) return json(400, { error: 'Email and password are required' });
      const authResponse = await fetch(`${env('SUPABASE_URL').replace(/\/$/, '')}/auth/v1/token?grant_type=password`, {
        method: 'POST', headers: { apikey: env('SUPABASE_ANON_KEY'), 'content-type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!authResponse.ok) return json(401, { error: 'Սխալ մուտքանուն կամ գաղտնաբառ' });
      const auth = await authResponse.json();
      const profile = await db(`profiles?select=id,full_name,role,active,is_available&id=eq.${encodeURIComponent(auth.user.id)}`);
      if (!profile?.length || profile[0].role !== 'driver' || !profile[0].active) return json(403, { error: 'Այս հաշիվը ակտիվ վարորդ չէ' });
      const token = makeSession('driver', profile[0].id);
      return json(200, { ok: true, driver: { id: profile[0].id, full_name: profile[0].full_name, is_available: profile[0].is_available } }, { 'set-cookie': `${cookieName}=${encodeURIComponent(token)}; ${cookieOptions}` });
    }

    if (action === 'driver-logout' && method === 'POST') {
      return json(200, { ok: true }, { 'set-cookie': `${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
    }

    if (action === 'driver-availability' && method === 'POST') {
      const driver = requireDriver(event);
      if (!driver) return json(401, { error: 'Վարորդի մուտք է պահանջվում' });
      const body = parseBody(event);
      if (typeof body?.is_available !== 'boolean') return json(400, { error: 'is_available must be true or false' });
      if (body.is_available) {
        const active = await db(`rides?select=id&assigned_driver=eq.${encodeURIComponent(driver.id)}&status=in.(assigned,accepted,approaching,with_passenger)&limit=1`);
        if (active?.length) return json(409, { error: 'Քեզ ակտիվ պատվեր է նշանակված։ Ավարտիր կամ չեղարկիր այն՝ հասանելի դառնալուց առաջ։' });
      }
      const updated = await db(`profiles?id=eq.${encodeURIComponent(driver.id)}&role=eq.driver&select=id,is_available`, {
        method: 'PATCH', headers: { Prefer: 'return=representation' },
        body: JSON.stringify({ is_available: body.is_available }),
      });
      if (!updated?.length) return json(404, { error: 'Վարորդի հաշիվը չի գտնվել' });
      return json(200, { ok: true, is_available: updated[0].is_available });
    }

    if (action === 'driver-orders' && method === 'GET') {
      const driver = requireDriver(event);
      if (!driver) return json(401, { error: 'Վարորդի մուտք է պահանջվում' });
      const rides = await db(`rides?select=id,pickup_address,destination_address,customer_note,status,created_at&assigned_driver=eq.${encodeURIComponent(driver.id)}&status=in.(assigned,accepted,approaching,with_passenger)&order=created_at.desc`);
      return json(200, { rides: rides || [] });
    }

    if (action === 'driver-status' && method === 'POST') {
      const driver = requireDriver(event);
      if (!driver) return json(401, { error: 'Վարորդի մուտք է պահանջվում' });
      const body = parseBody(event);
      const rideId = cleanText(body?.ride_id, 64);
      const status = cleanText(body?.status, 40);
      const allowed = ['accepted', 'approaching', 'with_passenger', 'completed', 'cancelled'];
      if (!rideId || !allowed.includes(status)) return json(400, { error: 'Invalid ride_id or status' });
      const current = await db(`rides?id=eq.${encodeURIComponent(rideId)}&assigned_driver=eq.${encodeURIComponent(driver.id)}&select=id,status`);
      if (!current?.length) return json(404, { error: 'Պատվերը չի գտնվել կամ ձեզ չի նշանակված' });
      if (!(driverTransitions[current[0].status] || []).includes(status)) {
        return json(409, { error: 'Կարգավիճակի այս փոփոխությունը թույլատրված չէ։ Թարմացրու պատվերների ցանկը։' });
      }
      const updated = await db(`rides?id=eq.${encodeURIComponent(rideId)}&assigned_driver=eq.${encodeURIComponent(driver.id)}&status=eq.${encodeURIComponent(current[0].status)}&select=id,status`, {
        method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ status }),
      });
      if (!updated?.length) return json(409, { error: 'Պատվերի կարգավիճակը արդեն փոխվել է։ Թարմացրու ցանկը։' });
      if (['completed', 'cancelled'].includes(status)) {
        // Release the driver only if they have no other active rides.
        const active = await db(`rides?select=id&assigned_driver=eq.${encodeURIComponent(driver.id)}&status=in.(assigned,accepted,approaching,with_passenger)&limit=1`);
        if (!active?.length) await db(`profiles?id=eq.${encodeURIComponent(driver.id)}&role=eq.driver`, { method: 'PATCH', body: JSON.stringify({ is_available: true }) });
      }
      return json(200, { ok: true, ride: updated[0] });
    }

    if (action === 'dispatcher-logout' && method === 'POST') {
      return json(200, { ok: true }, { 'set-cookie': `${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
    }

    if (action === 'dispatcher-orders' && method === 'GET') {
      if (!requireDispatcher(event)) return json(401, { error: 'Դիսպետչերի մուտք է պահանջվում' });
      const rides = await db('rides?select=id,customer_name,customer_phone,pickup_address,destination_address,customer_note,status,assigned_driver,assigned_by,created_at,updated_at&order=created_at.desc&limit=500');
      return json(200, { rides: rides || [] });
    }

    if (action === 'drivers' && method === 'GET') {
      if (!requireDispatcher(event)) return json(401, { error: 'Դիսպետչերի մուտք է պահանջվում' });
      const drivers = await db('profiles?select=id,full_name,phone,active,is_available&role=eq.driver&active=eq.true&order=full_name.asc');
      return json(200, { drivers: drivers || [] });
    }

    if (action === 'assign' && method === 'POST') {
      const session = requireDispatcher(event);
      if (!session) return json(401, { error: 'Դիսպետչերի մուտք է պահանջվում' });
      const body = parseBody(event);
      const rideId = cleanText(body?.ride_id, 64);
      let driverId = cleanText(body?.driver_id, 64);
      const auto = body?.auto === true;
      if (!rideId || (!auto && !driverId)) return json(400, { error: 'ride_id and driver_id are required' });
      if (auto) {
        const drivers = await db('profiles?select=id,full_name&role=eq.driver&active=eq.true&is_available=eq.true&order=created_at.asc');
        if (!drivers?.length) return json(409, { error: 'Ազատ վարորդներ չկան' });
        // Pick the available driver with the fewest active assigned rides.
        const activeRides = await db('rides?select=assigned_driver&status=in.(assigned,accepted,approaching,with_passenger)&assigned_driver=not.is.null');
        const counts = new Map();
        for (const ride of activeRides || []) counts.set(ride.assigned_driver, (counts.get(ride.assigned_driver) || 0) + 1);
        drivers.sort((a, b) => (counts.get(a.id) || 0) - (counts.get(b.id) || 0));
        driverId = drivers[0].id;
      }
      const driver = await db(`profiles?select=id&id=eq.${encodeURIComponent(driverId)}&role=eq.driver&active=eq.true`);
      if (!driver?.length) return json(400, { error: 'Ընտրված վարորդը ակտիվ չէ կամ գոյություն չունի' });
      const currentRide = await db(`rides?id=eq.${encodeURIComponent(rideId)}&select=id,status`);
      if (!currentRide?.length) return json(404, { error: 'Պատվերը չի գտնվել' });
      if (!['new', 'assigned'].includes(currentRide[0].status)) return json(409, { error: 'Այս պատվերն արդեն ընթացքի մեջ է կամ ավարտված է և չի կարող նորից բաշխվել։' });
      const updated = await db(`rides?id=eq.${encodeURIComponent(rideId)}&status=in.(new,assigned)&select=id,status,assigned_driver`, {
        method: 'PATCH', headers: { Prefer: 'return=representation' },
        body: JSON.stringify({ assigned_driver: driverId, assigned_by: null, status: 'assigned' }),
      });
      if (!updated?.length) return json(409, { error: 'Պատվերը միաժամանակ փոխվել է։ Թարմացրու ցանկը։' });
      await db(`profiles?id=eq.${encodeURIComponent(driverId)}&role=eq.driver`, { method: 'PATCH', body: JSON.stringify({ is_available: false }) });
      return json(200, { ok: true, ride: updated[0] });
    }

    if (action === 'update-status' && method === 'POST') {
      const session = requireDispatcher(event);
      if (!session) return json(401, { error: 'Դիսպետչերի մուտք է պահանջվում' });
      const body = parseBody(event);
      const rideId = cleanText(body?.ride_id, 64);
      const status = cleanText(body?.status, 40);
      const allowed = ['new', 'assigned', 'accepted', 'approaching', 'with_passenger', 'completed', 'cancelled'];
      if (!rideId || !allowed.includes(status)) return json(400, { error: 'Invalid ride_id or status' });
      const before = await db(`rides?id=eq.${encodeURIComponent(rideId)}&select=id,status,assigned_driver`);
      if (!before?.length) return json(404, { error: 'Պատվերը չի գտնվել' });
      const updated = await db(`rides?id=eq.${encodeURIComponent(rideId)}&select=id,status,assigned_driver`, {
        method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ status }),
      });
      if (!updated?.length) return json(404, { error: 'Պատվերը չի գտնվել' });
      if (before[0].assigned_driver && ['completed', 'cancelled'].includes(status)) {
        const driverId = before[0].assigned_driver;
        const active = await db(`rides?select=id&assigned_driver=eq.${encodeURIComponent(driverId)}&status=in.(assigned,accepted,approaching,with_passenger)&limit=1`);
        if (!active?.length) await db(`profiles?id=eq.${encodeURIComponent(driverId)}&role=eq.driver`, { method: 'PATCH', body: JSON.stringify({ is_available: true }) });
      }
      return json(200, { ok: true, ride: updated[0] });
    }

    return json(404, { error: 'Unknown action' });
  } catch (error) {
    console.error('VanTaxi API error:', error?.message || 'unknown');
    return json(500, { error: 'Ներքին սխալ։ Ստուգիր Netlify-ի function logs-ը։' });
  }
}
