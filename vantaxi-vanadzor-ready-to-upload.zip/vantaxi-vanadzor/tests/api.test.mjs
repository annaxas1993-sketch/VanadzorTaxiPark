import test from 'node:test';
import assert from 'node:assert/strict';
import { handler } from '../netlify/functions/api.mjs';

process.env.SUPABASE_URL = 'https://supabase.example';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'test-service-role';
process.env.SUPABASE_ANON_KEY = 'test-anon';
process.env.DISPATCHER_PASSWORD = 'a-strong-test-password';
process.env.SESSION_SECRET = 'test-secret-long-enough-for-session-signing';

const base = { headers: {}, queryStringParameters: {} };
const event = (method, action, body, headers = {}) => ({
  ...base,
  httpMethod: method,
  headers,
  queryStringParameters: { action },
  body: body === undefined ? undefined : JSON.stringify(body),
});

test('health endpoint reports configured API', async () => {
  const result = await handler(event('GET', 'health'));
  assert.equal(result.statusCode, 200);
  assert.equal(JSON.parse(result.body).ok, true);
});

test('public order rejects missing required fields', async () => {
  const result = await handler(event('POST', 'public-order', { customer_name: 'Անի' }));
  assert.equal(result.statusCode, 400);
});

test('public order stores validated data through Supabase REST', async () => {
  const previousFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    assert.match(String(url), /\/rest\/v1\/rides\?/);
    assert.equal(options.method, 'POST');
    const body = JSON.parse(options.body);
    assert.equal(body.customer_name, 'Անի');
    assert.equal(body.status, 'new');
    return new Response(JSON.stringify([{ id: 'ride-test-1', status: 'new', created_at: '2026-01-01T00:00:00Z' }]), { status: 201 });
  };
  try {
    const result = await handler(event('POST', 'public-order', {
      customer_name: ' Անի ', customer_phone: '+374 91 123456', pickup_address: 'Տիգրան Մեծ 1', destination_address: 'Կայարան', customer_note: ''
    }));
    assert.equal(result.statusCode, 201);
    assert.equal(JSON.parse(result.body).order.id, 'ride-test-1');
  } finally { globalThis.fetch = previousFetch; }
});

test('dispatcher login rejects an incorrect password', async () => {
  const result = await handler(event('POST', 'dispatcher-login', { password: 'wrong' }));
  assert.equal(result.statusCode, 401);
});

test('dispatcher orders requires an authenticated session', async () => {
  const result = await handler(event('GET', 'dispatcher-orders'));
  assert.equal(result.statusCode, 401);
});

test('unknown action returns 404', async () => {
  const result = await handler(event('GET', 'not-a-real-action'));
  assert.equal(result.statusCode, 404);
});
