create extension if not exists pgcrypto;
create type public.app_role as enum ('dispatcher','driver','admin');
create type public.ride_status as enum ('new','assigned','accepted','approaching','with_passenger','completed','cancelled');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null, phone text,
  role public.app_role not null default 'driver',
  active boolean not null default true, is_available boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.rides (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null, customer_phone text not null,
  pickup_address text not null, destination_address text not null, customer_note text,
  status public.ride_status not null default 'new',
  assigned_driver uuid references public.profiles(id),
  assigned_by uuid references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index rides_status_created_idx on public.rides(status, created_at desc);
create index rides_driver_status_idx on public.rides(assigned_driver, status);
create index profiles_role_active_idx on public.profiles(role, active, is_available);
create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger rides_updated_at before update on public.rides for each row execute function public.set_updated_at();
alter table public.profiles enable row level security;
alter table public.rides enable row level security;
