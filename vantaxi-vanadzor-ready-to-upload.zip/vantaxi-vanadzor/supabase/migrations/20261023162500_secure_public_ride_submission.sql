create or replace function public.submit_ride_order(
  p_customer_name text, p_customer_phone text, p_pickup_address text,
  p_destination_address text, p_customer_note text default null
) returns uuid language plpgsql security definer set search_path = public, pg_temp as $$
declare new_ride_id uuid;
begin
  if length(trim(coalesce(p_customer_name, ''))) < 2 or length(trim(p_customer_name)) > 120 then raise exception 'Invalid customer name'; end if;
  if length(regexp_replace(coalesce(p_customer_phone, ''), '[^0-9+]', '', 'g')) < 7 or length(p_customer_phone) > 40 then raise exception 'Invalid customer phone'; end if;
  if length(trim(coalesce(p_pickup_address, ''))) < 3 or length(p_pickup_address) > 300 then raise exception 'Invalid pickup address'; end if;
  if length(trim(coalesce(p_destination_address, ''))) < 3 or length(p_destination_address) > 300 then raise exception 'Invalid destination address'; end if;
  if p_customer_note is not null and length(p_customer_note) > 1000 then raise exception 'Customer note too long'; end if;
  insert into public.rides(customer_name, customer_phone, pickup_address, destination_address, customer_note)
  values (trim(p_customer_name), trim(p_customer_phone), trim(p_pickup_address), trim(p_destination_address), nullif(trim(coalesce(p_customer_note, '')), ''))
  returning id into new_ride_id;
  return new_ride_id;
end;
$$;
revoke all on function public.submit_ride_order(text,text,text,text,text) from public;
grant execute on function public.submit_ride_order(text,text,text,text,text) to anon, authenticated;
