import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  try {
    const body = await req.json();
    const customer_name = String(body.customer_name ?? "").trim();
    const customer_phone = String(body.customer_phone ?? "").trim();
    const pickup_address = String(body.pickup_address ?? "").trim();
    const destination_address = String(body.destination_address ?? "").trim();
    const customer_note = body.customer_note == null ? null : String(body.customer_note).trim();
    if (customer_name.length < 2 || customer_name.length > 120 ||
        customer_phone.replace(/[^0-9+]/g, "").length < 7 || customer_phone.length > 40 ||
        pickup_address.length < 3 || pickup_address.length > 300 ||
        destination_address.length < 3 || destination_address.length > 300 ||
        (customer_note !== null && customer_note.length > 1000)) {
      return new Response(JSON.stringify({ error: "Խնդրում ենք ստուգել լրացված տվյալները։" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    if (!supabaseUrl || !anonKey) {
      return new Response(JSON.stringify({ error: "Server configuration missing" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/submit_ride_order`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: anonKey, Authorization: `Bearer ${anonKey}` },
      body: JSON.stringify({ p_customer_name: customer_name, p_customer_phone: customer_phone,
        p_pickup_address: pickup_address, p_destination_address: destination_address,
        p_customer_note: customer_note }),
    });
    const result = await response.text();
    if (!response.ok) {
      console.error("Order RPC failed", response.status, result.slice(0, 300));
      return new Response(JSON.stringify({ error: "Պատվերը չհաջողվեց գրանցել։ Փորձեք կրկին։" }), {
        status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ success: true, order_id: result }), {
      status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch {
    return new Response(JSON.stringify({ error: "Սխալ հարցում։ Ստուգեք տվյալները։" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
